<?php
namespace Unifonic\API;


class Exception extends \Exception
{


}