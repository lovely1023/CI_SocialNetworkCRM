<?php


    return array(
        'AppSid' => ['zOXkshoPjaPYCWCtZummXGkJiM7cXz'],
        'ApiURL' => 'http://api.unifonic.com/rest/',
    );
